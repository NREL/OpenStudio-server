require 'optparse'
require 'openstudio-analysis'

options = {}
OptionParser.new do |opt|
  opt.on('--analysis_id ID') { |o| options[:analysis_id] = o }
  opt.on('--host host') { |o| options[:host] = o }
end.parse!

puts options

# Save some data to the database
puts 'Saving data back into the database via rails'
analysis = Analysis.find(options[:analysis_id])
analysis.results[:finalization] = {}
analysis.results[:finalization][:random_value] = 5
analysis.save!

puts 'Initializing ServerApi'
api = OpenStudio::Analysis::ServerApi.new(hostname: options[:host])
puts api
r = api.get_analysis_results(options[:analysis_id])
puts r
analysis.results[:finalization][:number_of_variables] = r[:variables].size
analysis.results[:finalization][:number_of_datapoints] = r[:data].size
analysis.save!
