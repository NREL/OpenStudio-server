touch "$ANALYSIS_DIRECTORY/initialize_ran.txt"
echo "intialize ran"