echo "initializing..." > "$ANALYSIS_DIRECTORY/initialize_ran.txt"
echo "initialize ran"