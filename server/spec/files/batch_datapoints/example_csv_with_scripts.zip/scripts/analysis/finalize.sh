touch "$ANALYSIS_DIRECTORY/finalize_ran.txt"
echo "finalize ran"