#!/usr/bin/env Rscript

library(Swift)
#TODO: take command line options to setup options
runAllSwiftTests()
