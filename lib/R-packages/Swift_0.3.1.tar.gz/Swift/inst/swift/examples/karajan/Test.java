public class Test {
  public static void main(String[] args) {
    System.out.println("Important output");
    System.err.println("Descriptive error message");
  }
}
