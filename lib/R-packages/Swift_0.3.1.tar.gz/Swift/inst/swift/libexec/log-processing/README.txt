
To properly generate log plots, you must:

1) Enable VDL/Karajan logging.

Make sure log4.properties contains:

log4j.logger.swift=DEBUG
