class Seed
  include Mongoid::Document
  include Mongoid::Timestamps





end
