class Analysis
  include Mongoid::Document
  include Mongoid::Timestamps
  include Mongoid::Paperclip

  require 'delayed_job_mongoid'

  field :uuid, :type => String
  field :_id, :type => String, default: -> { uuid || UUID.generate }
  field :version_uuid
  field :name, :type => String
  field :display_name, :type => String
  field :description, :type => String
  field :run_flag, :type => Boolean
  field :status, :type => String # enum on the status of the analysis (queued, started, completed)

  belongs_to :project

  has_many :data_points
  has_many :algorithms
  #has_many :problems

  has_mongoid_attached_file :seed_zip,
                            :url => "/assets/analyses/:id/:style/:basename.:extension",
                            :path => ":rails_root/public/assets/analyses/:id/:style/:basename.:extension"

  # validations
  #validates_format_of :uuid, :with => /[^0-]+/

  #validates_attachment :seed_zip, content_type: { content_type: "application/zip" }

  before_destroy :remove_dependencies

  def initialize_workers
    # load in the master and worker information if it doesn't already exist

    ip_file = "/home/ubuntu/ip_addresses"
    if !File.exists?(ip_file)
      ip_file = "/data/launch-instance/ip_addresses_vagrant"   # somehow check if this is a vagrant box
    end

    ips = File.read(ip_file).split("\n")
    ips.each do |ip|
      cols = ip.split("|")
      if cols[0] == "master"
        mn = MasterNode.find_or_create_by(:ip_address => cols[1])
        mn.hostname = cols[2]
        mn.cores = cols[3]
        mn.user = cols[4]
        #mn.password = cols[5].chomp
        mn.save!

        logger.info("Master node #{mn.inspect}")
      elsif cols[0] == "worker"
        wn = WorkerNode.find_or_create_by(:ip_address => cols[1])
        wn.hostname = cols[2]
        wn.cores = cols[3]
        wn.user = cols[4]
        wn.password = cols[5].chomp
        wn.save!

        logger.info("Worker node #{wn.inspect}")
      end
    end

    copy_data_to_workers()
  end

  def start
    # add into delayed job
    require 'rserve/simpler'
    require 'uuid'

    #create an instance for R

    @r = Rserve::Simpler.new
    puts "Setting working directory"
    @r.converse('setwd("/mnt/openstudio")')
    wd = @r.converse('getwd()')
    puts "R working dir = #{wd}"
    puts "starting cluster and running"
    @r.converse "library(snow)"
    @r.converse "library(snowfall)"
    @r.converse "library(RMongo)"

    self.status = 'started'
    self.run_flag = true
    self.save!

    # At this point we should really setup the JSON that can be sent to the worker nodes with everything it needs
    # This would allow us to easily replace the queuing system with rabbit or any other json based versions.

    # get the master ip address
    master_ip = MasterNode.first.ip_address
    logger.info("master ip: #{master_ip}")

    # I think we can do this with mongoid at the moment... no reason to make this complicated until we have to send
    # the data to the worker nodes
    @r.command() do
      %Q{
        ip <- "#{master_ip}"
        print(ip)
        #mongo <- mongoDbConnect("openstudio_server_development", host=ip, port=27017)
        #output <- dbRemoveQuery(mongo,"control","{_id:1}")
        #if (output != "ok"){stop(options("show.error.messages"="TRUE"),"cannot remove control flag in Mongo")}
        #input <- dbInsertDocument(mongo,"control",'{"_id":1,"run":"TRUE"}')
        #if (input != "ok"){stop(options("show.error.messages"="TRUE"),"cannot insert control flag in Mongo")}
        #flag <- dbGetQuery(mongo,"control",'{"_id":1}')
        #if (flag["run"] != "TRUE" ){stop(options("show.error.messages"="TRUE"),"run flag is not TRUE")}
        #dbDisconnect(mongo)

        #test the query of getting the run_flag
        mongo <- mongoDbConnect("openstudio_server_development", host=ip, port=27017)
        flag <- dbGetQuery(mongo, "analyses", '{_id:"#{self.id}"}')
        print(flag)

        print(flag["run_flag"])
        if (flag["run_flag"] == "true"  ){
          print("flag is set to true!")
        }
      }
    end

    # get the worker ips
    worker_ips_hash = {}
    worker_ips_hash[:worker_ips] = []

    WorkerNode.all.each do |wn|
      (1..wn.cores).each { |i| worker_ips_hash[:worker_ips] << wn.ip_address }
    end
    logger.info("worker ip hash: #{worker_ips_hash}")

    # update the status of all the datapoints and create a hash map
    data_points_hash = {}
    data_points_hash[:data_points] = []
    self.data_points.all.each do |dp|
      dp.status = 'queued'
      dp.save!
      data_points_hash[:data_points] << dp.uuid
    end
    logger.info(data_points_hash)

    @r.command(ips: worker_ips_hash.to_dataframe, dps: data_points_hash.to_dataframe) do
      %Q{
        sfInit(parallel=TRUE, type="SOCK", socketHosts=ips[,1])
        sfLibrary(RMongo)

        f <- function(x){
          mongo <- mongoDbConnect("openstudio_server_development", host="#{master_ip}", port=27017)
          flag <- dbGetQuery(mongo, "analyses", '{_id:"#{self.id}"}')
          if (flag["run_flag"] == "false" ){
            stop(options("show.error.messages"="TRUE"),"run flag is not TRUE")
          }
          dbDisconnect(mongo)

          y <- paste("/usr/local/rbenv/shims/ruby -I/usr/local/lib/ruby/site_ruby/2.0.0/ /mnt/openstudio/SimulateDataPoint.rb -u ",x," -d /mnt/openstudio/analysis/data_point_",x," -r AWS > /mnt/openstudio/",x,".log",sep="")
          #y <- "sleep 1; echo hello"
          z <- system(y,intern=TRUE)
          j <- length(z)
          z
        }

        sfExport("f")
        print(dps)

        results <- sfLapply(dps[,1], f)
        sfStop()
      }
    end

    #self.r_log = @r.converse(messages)

    # check if there are any other datapoints that need downloaded?
    download_data_from_workers
    self.status = 'completed'
    self.save!
  end
  handle_asynchronously :start, :queue => 'analysis'

  def run_r_analysis(no_delay = false)
    # check if there is already an analysis in the queue
    dj = Delayed::Job.where(queue: 'analysis').first

    if !dj.nil? || self.status == "queued" || self.status == "started"
      logger.info("analysis is already queued with #{dj}")
      return [false, "An analysis is already queued"]
    else
      logger.info("Initializing workers in database")
      self.initialize_workers

      logger.info("queuing up analysis #{@analysis}")
      self.status = 'queued'
      self.save!

      if !no_delay
        self.start
      else
        self.start_without_delay
      end

      return [true]
    end
  end

  def stop_analysis
    logger.info("stopping analysis")
    self.run_flag = false
    self.status = 'completed'
    self.save!
  end

  protected

  def remove_dependencies
    logger.info("Found #{self.data_points.size} records")
    self.data_points.each do |record|
      logger.info("removing #{record.id}")
      record.destroy
    end

    logger.info("Found #{self.algorithms.size} records")
    self.algorithms.each do |record|
      logger.info("removing #{record.id}")
      record.destroy
    end

  end

  private

  # copy the zip file over the various workers and extract the file.
  # if the file already exists, then it will overwrite the file
  # verify the behaviour of the zip extraction on top of an already existing analysis.
  def copy_data_to_workers
    # copy the datafiles over to the worker nodes
    WorkerNode.all.each do |wn|
      Net::SSH.start(wn.ip_address, wn.user, :password => wn.password) do |session|
        logger.info(self.inspect)
        session.scp.upload!(self.seed_zip.path, "/mnt/openstudio/")

        session.exec!("cd /mnt/openstudio && unzip -o #{self.seed_zip_file_name}") do |channel, stream, data|
          logger.info(data)
        end
        session.loop

      end
    end
  end

  # copy back the results to the master node if they are finished
  def download_data_from_workers
    self.data_points.and({downloaded: false}, {status: 'completed'}).each do |dp|
      dp.download_datapoint_from_worker
    end
  end


end
